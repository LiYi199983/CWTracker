import cv2
import matplotlib.pyplot as plt
import numpy as np
from collections import deque
import math

from tracker import matching
from tracker.basetrack import BaseTrack, TrackState
from tracker.kalman_filter import KalmanFilter
from tracker.gmc import GMC

from fast_reid.fast_reid_interfece import FastReIDInterface


import scipy.stats as st


class STrack(BaseTrack):
    shared_kalman = KalmanFilter()

    def __init__(self, tlwh, score, feat=None, feat_history=50):
        #feat是目标外观特征
        # wait activate
        self._tlwh = np.asarray(tlwh, dtype=np.float)
        self.kalman_filter = None
        self.mean, self.covariance = None, None
        self.is_activated = False

        self.q = 0.5
        self.score = score
        self.smooth_score = 0
        self.tracklet_len = 0
        self.hit = 0
        self.aff = 0


        self.smooth_feat = None  # 轨迹外观特征
        self.curr_feat = None
        if feat is not None:
            self.update_features(feat)
        self.features = deque([], maxlen=feat_history)

        self.alpha = 0.9

    def update_score(self, curr_score):
        if self.smooth_score == 0:
            self.smooth_score = curr_score
        else:
            self.smooth_score = self.q * self.smooth_score + (1 - self.q) * curr_score
        return self.smooth_score

    def update_aff(self, curr_aff):
        if self.aff == 0:
            self.aff = curr_aff
        else:
            self.aff = self.q * self.aff + (1 - self.q) * curr_aff
        return self.aff



    def update_features(self, feat):   #外观模型更新操作
        feat /= np.linalg.norm(feat)  #先归一话
        self.curr_feat = feat
        if self.smooth_feat is None:
            self.smooth_feat = feat
        else:
            self.smooth_feat = self.alpha * self.smooth_feat + (1 - self.alpha) * feat
        self.features.append(feat)
        self.smooth_feat /= np.linalg.norm(self.smooth_feat)  #用于求范数，归一化操作

    def predict(self):
        mean_state = self.mean.copy()
        if self.state != TrackState.Tracked:
            mean_state[7] = 0

        self.mean, self.covariance = self.kalman_filter.predict(mean_state, self.covariance)

    @staticmethod
    def multi_predict(stracks):
        if len(stracks) > 0:
            multi_mean = np.asarray([st.mean.copy() for st in stracks])
            multi_covariance = np.asarray([st.covariance for st in stracks])
            for i, st in enumerate(stracks):
                if st.state != TrackState.Tracked:
                    multi_mean[i][7] = 0
            multi_mean, multi_covariance = STrack.shared_kalman.multi_predict(multi_mean, multi_covariance)
            for i, (mean, cov) in enumerate(zip(multi_mean, multi_covariance)):
                stracks[i].mean = mean
                stracks[i].covariance = cov

    @staticmethod
    def multi_gmc(stracks, H=np.eye(2, 3)):
        if len(stracks) > 0:
            multi_mean = np.asarray([st.mean.copy() for st in stracks])
            multi_covariance = np.asarray([st.covariance for st in stracks])

            R = H[:2, :2]
            R8x8 = np.kron(np.eye(4, dtype=float), R)
            t = H[:2, 2]

            for i, (mean, cov) in enumerate(zip(multi_mean, multi_covariance)):
                mean = R8x8.dot(mean)
                mean[:2] += t
                cov = R8x8.dot(cov).dot(R8x8.transpose())

                stracks[i].mean = mean
                stracks[i].covariance = cov

    def activate(self, kalman_filter, frame_id):
        """Start a new tracklet"""
        self.kalman_filter = kalman_filter
        self.track_id = self.next_id()
        self.mean, self.covariance = self.kalman_filter.initiate(self.tlwh_to_xywh(self._tlwh))
        self.tracklet_len = 0
        self.state = TrackState.Tracked
        if frame_id == 1:
            self.is_activated = True
        self.frame_id = frame_id
        self.start_frame = frame_id
        self.smooth_score = self.score
        self.aff = self.score


    def re_activate(self, new_track, frame_id, aff, new_id=False):

        self.mean, self.covariance = self.kalman_filter.update(self.mean, self.covariance,
                                                               self.tlwh_to_xywh(new_track.tlwh))
        if new_track.curr_feat is not None:
            self.update_features(new_track.curr_feat)
        self.tracklet_len = 0
        self.state = TrackState.Tracked
        self.is_activated = True
        self.frame_id = frame_id
        if new_id:
            self.track_id = self.next_id()
        self.smooth_score = self.update_score(new_track.score)
        self.score = new_track.score
        self.aff = aff

    def update(self, new_track, frame_id, aff):
        """
        Update a matched track
        :type new_track: STrack
        :type frame_id: int
        :type update_feature: bool
        :return:
        """
        self.frame_id = frame_id
        self.tracklet_len += 1
        self.time_since_update = 0

        new_tlwh = new_track.tlwh
        self.mean, self.covariance = self.kalman_filter.update(self.mean, self.covariance, self.tlwh_to_xywh(new_tlwh))
        if new_track.curr_feat is not None:
            self.update_features(new_track.curr_feat)  # feat, ss,cs,Nu
        self.state = TrackState.Tracked
        self.is_activated = True
        new_track.smooth_score = self.update_score(new_track.score)
        self.score = new_track.score
        self.aff = self.update_aff(aff)


    @property
    def tlwh(self):
        """Get current position in bounding box format `(top left x, top left y,
                width, height)`.
        """
        if self.mean is None:
            return self._tlwh.copy()
        ret = self.mean[:4].copy()
        ret[:2] -= ret[2:] / 2
        return ret

    @property
    def tlbr(self):
        """Convert bounding box to format `(min x, min y, max x, max y)`, i.e.,
        `(top left, bottom right)`.
        """
        ret = self.tlwh.copy()
        ret[2:] += ret[:2]
        return ret

    @property
    def xywh(self):
        """Convert bounding box to format `(min x, min y, max x, max y)`, i.e.,
        `(top left, bottom right)`.
        """
        ret = self.tlwh.copy()
        ret[:2] += ret[2:] / 2.0
        return ret

    @staticmethod
    def tlwh_to_xyah(tlwh):
        """Convert bounding box to format `(center x, center y, aspect ratio,
        height)`, where the aspect ratio is `width / height`.
        """
        ret = np.asarray(tlwh).copy()
        ret[:2] += ret[2:] / 2
        ret[2] /= ret[3]
        return ret

    @staticmethod
    def tlwh_to_xywh(tlwh):
        """Convert bounding box to format `(center x, center y, width,
        height)`.
        """
        ret = np.asarray(tlwh).copy()
        ret[:2] += ret[2:] / 2
        return ret

    def to_xywh(self):
        return self.tlwh_to_xywh(self.tlwh)

    @staticmethod
    def tlbr_to_tlwh(tlbr):
        ret = np.asarray(tlbr).copy()
        ret[2:] -= ret[:2]
        return ret

    @staticmethod
    def tlwh_to_tlbr(tlwh):
        ret = np.asarray(tlwh).copy()
        ret[2:] += ret[:2]
        return ret

    def __repr__(self):
        return 'OT_{}_({}-{})'.format(self.track_id, self.start_frame, self.end_frame)


class CWTracker(object):
    def __init__(self, args, frame_rate=30):

        self.tracked_stracks = []  # type: list[STrack]
        self.lost_stracks = []  # type: list[STrack]
        self.removed_stracks = []  # type: list[STrack]
        BaseTrack.clear_count()


        self.frame_id = 0
        self.args = args
        self.track_low_thresh = args.track_low_thresh
        self.new_track_thresh = args.new_track_thresh
        print(self.new_track_thresh)
        self.frame_rate = frame_rate

        self.buffer_size = args.track_buffer
        self.max_time_lost = self.buffer_size
        self.kalman_filter = KalmanFilter()

        # ReID module
        self.weight_lambda = args.weight_lambda

        if args.with_reid:
            self.encoder = FastReIDInterface(args.fast_reid_config, args.fast_reid_weights, args.device)

        self.cmc = args.cmc
        self.gmc = GMC(method=args.cmc_method, verbose=[args.name, args.ablation])

    def update(self, output_results, img):
        self.frame_id += 1
        activated_starcks = []
        refind_stracks = []
        lost_stracks = []
        removed_stracks = []

        if len(output_results):  # 检测结果整形成5列的
            if output_results.shape[1] == 5:
                scores = output_results[:, 4]
                bboxes = output_results[:, :4]
            else:
                # output_results = output_results.cpu().numpy()    #记得开这个，如果有问题的话
                scores = output_results[:, 4] * output_results[:, 5]
                bboxes = output_results[:, :4]  # x1y1x2y2

            # Find high threshold detections
            remain_inds = scores > self.args.track_low_thresh
            dets = bboxes[remain_inds]
            scores_keep = scores[remain_inds]

        else:
            bboxes = []
            scores = []
            classes = []
            dets = []
            scores_keep = []

        '''Extract embeddings '''
        if self.args.with_reid:
            features_keep = self.encoder.inference(img, dets)  # 输入图片，和全部的高分检测，得出目标特征  只嵌入高分的检测

        if len(dets) > 0:
            '''Detections'''
            if self.args.with_reid:
                detections = [STrack(STrack.tlbr_to_tlwh(tlbr), s, f) for
                              (tlbr, s, f) in zip(dets, scores_keep, features_keep)]  # 构建包括外观特征的高分检测集合
            else:
                detections = [STrack(STrack.tlbr_to_tlwh(tlbr), s) for
                              (tlbr, s) in zip(dets, scores_keep)]
        else:
            detections = []

        ''' Add newly detected tracklets to tracked_stracks'''
        unconfirmed = []
        tracked_stracks = []  # type: list[STrack]   #构造一个包含所有轨迹的空集
        for track in self.tracked_stracks:
            if not track.is_activated:
                unconfirmed.append(track)  # 更据轨迹的状态，分为不确定轨迹列表和确定的轨迹列表
            else:
                tracked_stracks.append(track)


        ''' Step 2: First association, with high score detection boxes'''
        strack_pool = joint_stracks(tracked_stracks, self.lost_stracks)   #激活轨迹+中断轨迹

        # Predict the current location with KF
        STrack.multi_predict(strack_pool)  # 用kf预测当前位置

        #fix camera motion
        if self.cmc:
            warp = self.gmc.apply(img, dets)
            STrack.multi_gmc(strack_pool, warp)
            STrack.multi_gmc(unconfirmed, warp)

        # Associate with high score detection boxes
        ious_dists = matching.iou_distance(strack_pool, detections, type='iou')# 计算两个列表间的IOU距离
        mask_ious_dists, mask, ious_sim, mask_sim = matching.mask_iou(ious_dists, detections, strack_pool)


        if self.args.with_reid:
            emb_dists = matching.embedding_distance(strack_pool, detections)
            emb_dists[emb_dists > 1] = 1
            mask_emb_dists = np.multiply(emb_dists, mask)
            raw_emb_dists = mask_emb_dists.copy()
            dists = self.weight_lambda * mask_ious_dists + (1 - self.weight_lambda) * mask_emb_dists  # 构造了一个融合的成本矩阵
        else:
            dists = mask_ious_dists


        matches, u_track, u_detection = matching.linear_assignment(dists,
                                                                   thresh=self.args.match_thresh)  # 匈牙利算法求匹配，注意这里没匹配上的检测是直接生成新轨迹的

        for itracked, idet in matches:  # 对匹配对，进行管理
            track = strack_pool[itracked]
            det = detections[idet]  # 更据引索，找到轨迹和检测
            if track.state == TrackState.Tracked:
                track.update(detections[idet], self.frame_id, 1-ious_dists[itracked, idet])
                # print('tracked',track.aff)
                activated_starcks.append(track) # 如果轨迹的状态是跟踪，那就KF更新，并把轨迹放到激活轨迹列表里
            elif track.state == TrackState.Lost:
                track.re_activate(det, self.frame_id, 1-ious_dists[itracked, idet], new_id=False)  # 否则就重新激活轨迹，并放到找回轨迹列表里
                # print('refind',track.aff)
                refind_stracks.append(track)



        # association the untrack to the low score detections
        detections = [detections[i] for i in u_detection]
        r_tracked_stracks = [strack_pool[i] for i in u_track if strack_pool[i].state == TrackState.Tracked]  #中断轨迹不能参与第二次匹配
        r_tracked_stracks = joint_stracks(r_tracked_stracks, unconfirmed)   #未匹配激活轨迹+新轨迹
        dists = matching.iou_distance(r_tracked_stracks, detections, type='iou')  # 未匹配上的轨迹和低分检测匹配
        dists = matching.fuse_score(dists, detections)
        matches, u_track2, u_detection_second = matching.linear_assignment(dists, thresh=self.args.match_thresh2)
        for itracked, idet in matches:  # 轨迹状态管理
            track = r_tracked_stracks[itracked]
            det = detections[idet]
            if track.state == TrackState.Tracked:
                track.update(det, self.frame_id, 1-dists[itracked, idet])
                # print('sectracked', track.aff)
                activated_starcks.append(track)
            elif not track.is_activated:   #对与考察期的轨迹，直接激活，放到激活轨迹的列表中去
                r_tracked_stracks[itracked].update(detections[idet], self.frame_id, 1-dists[itracked, idet])  # 匹配上的未确定轨迹直接更新激活
                # print('newtracked', track.aff)
                activated_starcks.append(r_tracked_stracks[itracked])   #激活新轨迹

        for it in u_track2:
            track = r_tracked_stracks[it]
            if not track.state == TrackState.Lost:  # 如果没匹配上的轨迹不是lost状态，就把他变成lost状态，并放到lost轨迹中
                track.mark_lost()
                lost_stracks.append(track)    #未匹配的还是中断
            elif not track.is_activated:
                track.mark_removed()
                removed_stracks.append(track)

        """ Step 4: Init new stracks"""

        for inew in u_detection_second:  # 高分检测中，还未匹配成功的直接生成新轨迹
            track = detections[inew]
            if track.score < self.args.new_track_thresh:  # 只有大于这个阈值，才能生成新的轨迹
                continue
            track.activate(self.kalman_filter, self.frame_id)
            # print('newdet',track.aff)
            activated_starcks.append(track)


        """ Step 5: Update state"""
        for track in self.lost_stracks:  # 丢失的轨迹状态更新
            if self.frame_id - track.end_frame > self.max_time_lost:  # 删除寿命过长的轨迹
                track.mark_removed()
                removed_stracks.append(track)

        """ Merge """
        self.tracked_stracks = [t for t in self.tracked_stracks if t.state == TrackState.Tracked]  # 跟踪轨迹集合更新，剔除不在跟踪状态的
        self.tracked_stracks = joint_stracks(self.tracked_stracks, activated_starcks)  # 加入新激活的
        self.tracked_stracks = joint_stracks(self.tracked_stracks, refind_stracks)  # 加入重新找到的
        self.lost_stracks = sub_stracks(self.lost_stracks, self.tracked_stracks)  # 把丢失的轨迹从转移到前者列表
        self.lost_stracks.extend(lost_stracks)
        self.lost_stracks = sub_stracks(self.lost_stracks, self.removed_stracks)  # 丢失轨迹转移
        self.removed_stracks.extend(removed_stracks)
        self.tracked_stracks, self.lost_stracks = remove_duplicate_stracks(self.tracked_stracks,
                                                                           self.lost_stracks)  # 最后检查去除重复的轨迹

        # output_stracks = [track for track in self.tracked_stracks if track.is_activated]
        output_stracks = [track for track in self.tracked_stracks]  # 输出所有激活状态的轨迹

        return output_stracks


def joint_stracks(tlista, tlistb):
    exists = {}
    res = []
    for t in tlista:
        exists[t.track_id] = 1
        res.append(t)
    for t in tlistb:
        tid = t.track_id
        if not exists.get(tid, 0):
            exists[tid] = 1
            res.append(t)
    return res


def sub_stracks(tlista, tlistb):
    stracks = {}
    for t in tlista:
        stracks[t.track_id] = t
    for t in tlistb:
        tid = t.track_id
        if stracks.get(tid, 0):
            del stracks[tid]
    return list(stracks.values())





def remove_duplicate_stracks(stracksa, stracksb):
    pdist = matching.iou_distance(stracksa, stracksb)
    pairs = np.where(pdist < 0.15)
    dupa, dupb = list(), list()
    for p, q in zip(*pairs):
        timep = stracksa[p].frame_id - stracksa[p].start_frame
        timeq = stracksb[q].frame_id - stracksb[q].start_frame
        if timep > timeq:
            dupb.append(q)
        else:
            dupa.append(p)
    resa = [t for i, t in enumerate(stracksa) if not i in dupa]
    resb = [t for i, t in enumerate(stracksb) if not i in dupb]
    return resa, resb
