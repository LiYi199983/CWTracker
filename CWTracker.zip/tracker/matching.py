import numpy as np
import scipy
import lap
from scipy.spatial.distance import cdist

from cython_bbox import bbox_overlaps as bbox_ious
from tracker import kalman_filter
import pandas as pd

import torch
import math




def merge_matches(m1, m2, shape):
    O,P,Q = shape
    m1 = np.asarray(m1)
    m2 = np.asarray(m2)

    M1 = scipy.sparse.coo_matrix((np.ones(len(m1)), (m1[:, 0], m1[:, 1])), shape=(O, P))
    M2 = scipy.sparse.coo_matrix((np.ones(len(m2)), (m2[:, 0], m2[:, 1])), shape=(P, Q))

    mask = M1*M2
    match = mask.nonzero()
    match = list(zip(match[0], match[1]))
    unmatched_O = tuple(set(range(O)) - set([i for i, j in match]))
    unmatched_Q = tuple(set(range(Q)) - set([j for i, j in match]))

    return match, unmatched_O, unmatched_Q


def _indices_to_matches(cost_matrix, indices, thresh):
    matched_cost = cost_matrix[tuple(zip(*indices))]
    matched_mask = (matched_cost <= thresh)

    matches = indices[matched_mask]
    unmatched_a = tuple(set(range(cost_matrix.shape[0])) - set(matches[:, 0]))
    unmatched_b = tuple(set(range(cost_matrix.shape[1])) - set(matches[:, 1]))

    return matches, unmatched_a, unmatched_b


def linear_assignment(cost_matrix, thresh):
    if cost_matrix.size == 0:
        return np.empty((0, 2), dtype=int), tuple(range(cost_matrix.shape[0])), tuple(range(cost_matrix.shape[1]))
    matches, unmatched_a, unmatched_b = [], [], []
    cost, x, y = lap.lapjv(cost_matrix, extend_cost=True, cost_limit=thresh)
    for ix, mx in enumerate(x):
        if mx >= 0:
            matches.append([ix, mx])
    unmatched_a = np.where(x < 0)[0]
    unmatched_b = np.where(y < 0)[0]
    matches = np.asarray(matches)
    return matches, unmatched_a, unmatched_b


def bbox_overlaps_ciou(bboxes1, bboxes2):
    cious = torch.zeros((len(bboxes1), len(bboxes2)), dtype=np.float)
    if len(bboxes1) * len(bboxes2) == 0:
        return cious

    bboxes1 = np.ascontiguousarray(bboxes1, dtype=np.float)
    bboxes2 = np.ascontiguousarray(bboxes2, dtype=np.float)

    bboxes1 = torch.Tensor(bboxes1)
    bboxes2 = torch.Tensor(bboxes2)

    rows = bboxes1.shape[0]
    cols = bboxes2.shape[0]
    cious = torch.zeros((rows, cols))
    exchange = False
    if bboxes1.shape[0] > bboxes2.shape[0]:
        bboxes1, bboxes2 = bboxes2, bboxes1
        cious = torch.zeros((cols, rows))
        exchange = True

    bboxes1 = bboxes1[:, None, :]
    bboxes2 = bboxes2[None, :, :]
    w1 = bboxes1[..., 2] - bboxes1[..., 0]
    h1 = bboxes1[..., 3] - bboxes1[..., 1]
    w2 = bboxes2[..., 2] - bboxes2[..., 0]
    h2 = bboxes2[..., 3] - bboxes2[..., 1]

    area1 = w1 * h1
    area2 = w2 * h2

    center_x1 = (bboxes1[..., 2] + bboxes1[..., 0]) / 2
    center_y1 = (bboxes1[..., 3] + bboxes1[..., 1]) / 2
    center_x2 = (bboxes2[..., 2] + bboxes2[..., 0]) / 2
    center_y2 = (bboxes2[..., 3] + bboxes2[..., 1]) / 2

    inter_max_xy = torch.min(bboxes1[..., 2:], bboxes2[..., 2:])
    inter_min_xy = torch.max(bboxes1[..., :2], bboxes2[..., :2])
    out_max_xy = torch.max(bboxes1[..., 2:], bboxes2[..., 2:])
    out_min_xy = torch.min(bboxes1[..., :2], bboxes2[..., :2])

    inter = torch.clamp((inter_max_xy - inter_min_xy), min=0)
    inter_area = inter[:, :, 0] * inter[:, :, 1]
    inter_diag = (center_x1 - center_x2) ** 2 + (center_y1 - center_y2) ** 2
    outer = torch.clamp((out_max_xy - out_min_xy), min=0)
    outer_diag = (outer[:, :, 0] ** 2) + (outer[:, :, 1] ** 2)
    union = area1 + area2 - inter_area
    u = (inter_diag) / outer_diag
    iou = inter_area / union
    with torch.no_grad():
        arctan = torch.atan(w2 / h2) - torch.atan(w1 / h1)
        v = (4 / (math.pi ** 2)) * torch.pow((torch.atan(w2 / h2) - torch.atan(w1 / h1)), 2)
        S = 1 - iou
        alpha = v / (S + v)
        w_temp = 2 * w1
    ar = (8 / (math.pi ** 2)) * arctan * ((w1 - w_temp) * h1)
    cious = iou - (u + alpha * ar)
    cious = torch.clamp(cious, min=-1.0, max=1.0)
    if exchange:
        cious = cious.T
    return cious


def bbox_overlaps_giou(bboxes1, bboxes2):
    giou = torch.zeros((len(bboxes1), len(bboxes2)), dtype=np.float)
    if len(bboxes1) * len(bboxes2) == 0:
        return giou

    bboxes1 = np.ascontiguousarray(bboxes1, dtype=np.float)
    bboxes2 = np.ascontiguousarray(bboxes2, dtype=np.float)

    bboxes1 = torch.Tensor(bboxes1)
    bboxes2 = torch.Tensor(bboxes2)

    rows = bboxes1.shape[0]
    cols = bboxes2.shape[0]
    giou = torch.zeros((rows, cols))
    exchange = False
    if bboxes1.shape[0] > bboxes2.shape[0]:
        bboxes1, bboxes2 = bboxes2, bboxes1
        giou = torch.zeros((cols, rows))
        exchange = True

    bboxes1 = bboxes1[:, None, :]
    bboxes2 = bboxes2[None, :, :]
    w1 = bboxes1[..., 2] - bboxes1[..., 0]
    h1 = bboxes1[..., 3] - bboxes1[..., 1]
    w2 = bboxes2[..., 2] - bboxes2[..., 0]
    h2 = bboxes2[..., 3] - bboxes2[..., 1]

    area1 = w1 * h1
    area2 = w2 * h2

    inter_max_xy = torch.min(bboxes1[..., 2:], bboxes2[..., 2:])
    inter_min_xy = torch.max(bboxes1[..., :2], bboxes2[..., :2])
    out_max_xy = torch.max(bboxes1[..., 2:], bboxes2[..., 2:])
    out_min_xy = torch.min(bboxes1[..., :2], bboxes2[..., :2])

    inter = torch.clamp((inter_max_xy - inter_min_xy), min=0)
    inter_area = inter[:, :, 0] * inter[:, :, 1]

    outer = torch.clamp((out_max_xy - out_min_xy), min=0)
    outer_area = outer[:, :, 0] * outer[:, :, 1]
    union = area1 + area2 - inter_area

    iou = inter_area / union

    giou = iou - (outer_area - union) / outer_area
    giou = torch.clamp(giou, min=-1.0, max=1.0)
    if exchange:
        giou = giou.T
    return giou


def bbox_overlaps_diou(bboxes1, bboxes2):
    diou = torch.zeros((len(bboxes1), len(bboxes2)), dtype=np.float)
    if len(bboxes1) * len(bboxes2) == 0:
        return diou
    bboxes1 = np.ascontiguousarray(bboxes1, dtype=np.float)
    bboxes2 = np.ascontiguousarray(bboxes2, dtype=np.float)

    bboxes1 = torch.Tensor(bboxes1)
    bboxes2 = torch.Tensor(bboxes2)
    rows = bboxes1.shape[0]
    cols = bboxes2.shape[0]
    diou = torch.zeros((rows, cols))
    exchange = False
    if bboxes1.shape[0] > bboxes2.shape[0]:
        bboxes1, bboxes2 = bboxes2, bboxes1
        diou = torch.zeros((cols, rows))
        exchange = True
    # #xmin,ymin,xmax,ymax->[:,0],[:,1],[:,2],[:,3]
    bboxes1 = bboxes1[:, None, :]
    bboxes2 = bboxes2[None, :, :]
    w1 = bboxes1[..., 2] - bboxes1[..., 0]
    h1 = bboxes1[..., 3] - bboxes1[..., 1]
    w2 = bboxes2[..., 2] - bboxes2[..., 0]
    h2 = bboxes2[..., 3] - bboxes2[..., 1]

    area1 = w1 * h1
    area2 = w2 * h2

    center_x1 = (bboxes1[..., 2] + bboxes1[..., 0]) / 2
    center_y1 = (bboxes1[..., 3] + bboxes1[..., 1]) / 2
    center_x2 = (bboxes2[..., 2] + bboxes2[..., 0]) / 2
    center_y2 = (bboxes2[..., 3] + bboxes2[..., 1]) / 2

    inter_max_xy = torch.min(bboxes1[..., 2:], bboxes2[..., 2:])
    inter_min_xy = torch.max(bboxes1[..., :2], bboxes2[..., :2])
    out_max_xy = torch.max(bboxes1[..., 2:], bboxes2[..., 2:])
    out_min_xy = torch.min(bboxes1[..., :2], bboxes2[..., :2])

    inter = torch.clamp((inter_max_xy - inter_min_xy), min=0)
    inter_area = inter[:, :, 0] * inter[:, :, 1]
    inter_diag = (center_x2 - center_x1) ** 2 + (center_y2 - center_y1) ** 2
    outer = torch.clamp((out_max_xy - out_min_xy), min=0)
    outer_diag = (outer[:, :, 0] ** 2) + (outer[:,:, 1] ** 2)
    union = area1 + area2 - inter_area
    dious = inter_area / union - (inter_diag) / outer_diag
    dious = torch.clamp(dious, min=-1.0, max=1.0)
    if exchange:
        dious = dious.T
    return dious

def bbox_overlaps_ceiou(bboxes1, bboxes2):
    eiou = torch.zeros((len(bboxes1), len(bboxes2)), dtype=np.float)
    if len(bboxes1) * len(bboxes2) == 0:
        return eiou
    bboxes1 = np.ascontiguousarray(bboxes1, dtype=np.float)
    bboxes2 = np.ascontiguousarray(bboxes2, dtype=np.float)

    bboxes1 = torch.Tensor(bboxes1)
    bboxes2 = torch.Tensor(bboxes2)
    rows = bboxes1.shape[0]
    cols = bboxes2.shape[0]
    eiou = torch.zeros((rows, cols))
    exchange = False
    if bboxes1.shape[0] > bboxes2.shape[0]:
        bboxes1, bboxes2 = bboxes2, bboxes1
        eiou = torch.zeros((cols, rows))
        exchange = True
    # #xmin,ymin,xmax,ymax->[:,0],[:,1],[:,2],[:,3]  xyxy tlbr
    bboxes1 = bboxes1[:, None, :]
    bboxes2 = bboxes2[None, :, :]
    w1 = bboxes1[..., 2] - bboxes1[..., 0]
    h1 = bboxes1[..., 3] - bboxes1[..., 1]
    w2 = bboxes2[..., 2] - bboxes2[..., 0]
    h2 = bboxes2[..., 3] - bboxes2[..., 1]

    area1 = w1 * h1
    area2 = w2 * h2

    center_x1 = (bboxes1[..., 2] + bboxes1[..., 0]) / 2
    center_y1 = (bboxes1[..., 3] + bboxes1[..., 1]) / 2
    center_x2 = (bboxes2[..., 2] + bboxes2[..., 0]) / 2
    center_y2 = (bboxes2[..., 3] + bboxes2[..., 1]) / 2

    inter_max_xy = torch.min(bboxes1[..., 2:], bboxes2[..., 2:])
    inter_min_xy = torch.max(bboxes1[..., :2], bboxes2[..., :2])
    out_max_xy = torch.max(bboxes1[..., 2:], bboxes2[..., 2:])
    out_min_xy = torch.min(bboxes1[..., :2], bboxes2[..., :2])

    wh = out_max_xy - out_min_xy
    cw = wh[:, :, 0]
    ch = wh[:, :, 1]
    eps = 1e-7

    inter = torch.clamp((inter_max_xy - inter_min_xy), min=0)
    inter_area = inter[:, :, 0] * inter[:, :, 1]
    inter_diag = (center_x2 - center_x1) ** 2 + (center_y2 - center_y1) ** 2
    outer = torch.clamp((out_max_xy - out_min_xy), min=0)
    outer_diag = (outer[:, :, 0] ** 2) + (outer[:, :, 1] ** 2)
    rho_w2 = (w1 - w2) ** 2
    rho_h2 = (h1 - h2) ** 2
    cw2 = cw ** 2 + eps  # 这里是宽度
    ch2 = ch ** 2 + eps

    union = area1 + area2 - inter_area
    eious = (0.8 * inter_area / union) + (0.1 * (1-(inter_diag / outer_diag))) + (0.1 * (1-(rho_h2 / ch2)))
    # eious = (0.9 * inter_area / union) + (0.1 * (1 - (inter_diag / outer_diag)))
    # eious = (0. * inter_area / union) + (0.3 * (inter_diag) / outer_diag)
    eious = torch.clamp(eious, min=0, max=1.0)
    if exchange:
        eious = eious.T
    return eious
    # normalized_eious = (eious + 1) / 2  # 将结果归一化到 [0, 1] 范围内
    # return normalized_eious


def bbox_overlaps_eiou(bboxes1, bboxes2):
    eiou = torch.zeros((len(bboxes1), len(bboxes2)), dtype=np.float)
    if len(bboxes1) * len(bboxes2) == 0:
        return eiou
    bboxes1 = np.ascontiguousarray(bboxes1, dtype=np.float)
    bboxes2 = np.ascontiguousarray(bboxes2, dtype=np.float)

    bboxes1 = torch.Tensor(bboxes1)
    bboxes2 = torch.Tensor(bboxes2)
    rows = bboxes1.shape[0]
    cols = bboxes2.shape[0]
    eiou = torch.zeros((rows, cols))
    exchange = False
    if bboxes1.shape[0] > bboxes2.shape[0]:
        bboxes1, bboxes2 = bboxes2, bboxes1
        eiou = torch.zeros((cols, rows))
        exchange = True
    # #xmin,ymin,xmax,ymax->[:,0],[:,1],[:,2],[:,3]  xyxy tlbr
    bboxes1 = bboxes1[:, None, :]
    bboxes2 = bboxes2[None, :, :]
    w1 = bboxes1[..., 2] - bboxes1[..., 0]
    h1 = bboxes1[..., 3] - bboxes1[..., 1]
    w2 = bboxes2[..., 2] - bboxes2[..., 0]
    h2 = bboxes2[..., 3] - bboxes2[..., 1]

    area1 = w1 * h1
    area2 = w2 * h2

    center_x1 = (bboxes1[..., 2] + bboxes1[..., 0]) / 2
    center_y1 = (bboxes1[..., 3] + bboxes1[..., 1]) / 2
    center_x2 = (bboxes2[..., 2] + bboxes2[..., 0]) / 2
    center_y2 = (bboxes2[..., 3] + bboxes2[..., 1]) / 2

    inter_max_xy = torch.min(bboxes1[..., 2:], bboxes2[..., 2:])
    inter_min_xy = torch.max(bboxes1[..., :2], bboxes2[..., :2])
    out_max_xy = torch.max(bboxes1[..., 2:], bboxes2[..., 2:])
    out_min_xy = torch.min(bboxes1[..., :2], bboxes2[..., :2])

    wh = out_max_xy - out_min_xy
    cw = wh[:, :, 0]
    ch = wh[:, :, 1]
    eps = 1e-7

    inter = torch.clamp((inter_max_xy - inter_min_xy), min=0)
    inter_area = inter[:, :, 0] * inter[:, :, 1]
    inter_diag = (center_x2 - center_x1) ** 2 + (center_y2 - center_y1) ** 2
    outer = torch.clamp((out_max_xy - out_min_xy), min=0)
    outer_diag = (outer[:, :, 0] ** 2) + (outer[:, :, 1] ** 2)
    rho_w2 = (w1 - w2) ** 2
    rho_h2 = (h1 - h2) ** 2
    cw2 = cw ** 2 + eps   #这里是宽度
    ch2 = ch ** 2 + eps

    union = area1 + area2 - inter_area
    eious = inter_area / union - (inter_diag) / outer_diag - (rho_w2) / cw2 - (rho_h2) / ch2
    eious = torch.clamp(eious, min=-3.0, max=1.0)
    if exchange:
        eious = eious.T
    return eious



def ious(atlbrs, btlbrs):
    """
    Compute cost based on IoU
    :type atlbrs: list[tlbr] | np.ndarray
    :type atlbrs: list[tlbr] | np.ndarray

    :rtype ious np.ndarray
    """
    ious = np.zeros((len(atlbrs), len(btlbrs)), dtype=np.float)
    if ious.size == 0:
        return ious

    ious = bbox_ious(
        np.ascontiguousarray(atlbrs, dtype=np.float),   #这里的ascontiguo是提高代码运行效率的
        np.ascontiguousarray(btlbrs, dtype=np.float)
    )

    return ious


def tlbr_expand(tlbr, scale=1.3):  #这不就是BIOU？
    w = tlbr[..., 2] - tlbr[..., 0]
    h = tlbr[..., 3] - tlbr[..., 1]

    half_scale = 0.5 * scale

    tlbr[..., 0] -= half_scale * w
    tlbr[..., 1] -= half_scale * h
    tlbr[..., 2] += half_scale * w
    tlbr[..., 3] += half_scale * h

    return tlbr

def tlbr_expandwithscore(tlbr, track_score):
    w = tlbr[..., 2] - tlbr[..., 0]
    h = tlbr[..., 3] - tlbr[..., 1]
    scale = 1 - track_score
    scale = np.minimum(scale, 0.5)
    half_scale = 0.5 * scale

    tlbr[..., 0] -= half_scale[..., 0] * w
    tlbr[..., 1] -= half_scale[..., 0] * h
    tlbr[..., 2] += half_scale[..., 0] * w
    tlbr[..., 3] += half_scale[..., 0] * h

    return tlbr


def bbox_overlaps_biou(bboxes1, bboxes2):   #--轨迹--检测
    biou = torch.zeros((len(bboxes1), len(bboxes2)), dtype=np.float)
    if len(bboxes1) * len(bboxes2) == 0:
        return biou
    bboxes1 = np.ascontiguousarray(bboxes1, dtype=np.float)
    bboxes2 = np.ascontiguousarray(bboxes2, dtype=np.float)

    bboxes1 = torch.Tensor(bboxes1)
    bboxes1 = tlbr_expand(bboxes1, scale=1.3)
    bboxes2 = torch.Tensor(bboxes2)
    rows = bboxes1.shape[0]
    cols = bboxes2.shape[0]
    biou = torch.zeros((rows, cols))
    exchange = False
    if bboxes1.shape[0] > bboxes2.shape[0]:
        bboxes1, bboxes2 = bboxes2, bboxes1
        biou = torch.zeros((cols, rows))
        exchange = True
    # #xmin,ymin,xmax,ymax->[:,0],[:,1],[:,2],[:,3]  xyxy tlbr
    bboxes1 = bboxes1[:, None, :]
    bboxes2 = bboxes2[None, :, :]
    w1 = bboxes1[..., 2] - bboxes1[..., 0]
    h1 = bboxes1[..., 3] - bboxes1[..., 1]
    w2 = bboxes2[..., 2] - bboxes2[..., 0]
    h2 = bboxes2[..., 3] - bboxes2[..., 1]

    area1 = w1 * h1
    area2 = w2 * h2

    inter_max_xy = torch.min(bboxes1[..., 2:], bboxes2[..., 2:])
    inter_min_xy = torch.max(bboxes1[..., :2], bboxes2[..., :2])

    inter = torch.clamp((inter_max_xy - inter_min_xy), min=0)
    inter_area = inter[:, :, 0] * inter[:, :, 1]

    union = area1 + area2 - inter_area
    bious = inter_area / union
    bious = torch.clamp(bious, min=-1.0, max=1.0)
    if exchange:
        bious = bious.T
    return bious

def bbox_overlaps_cbiou(bboxes1, bboxes2, track_score, det_score):   #--轨迹--检测
    cbiou = torch.zeros((len(bboxes1), len(bboxes2)), dtype=np.float)
    if len(bboxes1) * len(bboxes2) == 0:
        return cbiou
    bboxes1 = np.ascontiguousarray(bboxes1, dtype=np.float)
    bboxes2 = np.ascontiguousarray(bboxes2, dtype=np.float)
    track_score = np.ascontiguousarray(track_score, dtype=np.float)
    det_score = np.ascontiguousarray(det_score, dtype=np.float)
    bboxes1 = tlbr_expandwithscore(bboxes1, track_score)
    bboxes2 = tlbr_expandwithscore(bboxes2, det_score)

    bboxes1 = torch.Tensor(bboxes1)
    bboxes2 = torch.Tensor(bboxes2)
    rows = bboxes1.shape[0]
    cols = bboxes2.shape[0]
    cbiou = torch.zeros((rows, cols))
    exchange = False
    if bboxes1.shape[0] > bboxes2.shape[0]:
        bboxes1, bboxes2 = bboxes2, bboxes1
        cbiou = torch.zeros((cols, rows))
        exchange = True
    # #xmin,ymin,xmax,ymax->[:,0],[:,1],[:,2],[:,3]  xyxy tlbr
    bboxes1 = bboxes1[:, None, :]
    bboxes2 = bboxes2[None, :, :]
    w1 = bboxes1[..., 2] - bboxes1[..., 0]
    h1 = bboxes1[..., 3] - bboxes1[..., 1]
    w2 = bboxes2[..., 2] - bboxes2[..., 0]
    h2 = bboxes2[..., 3] - bboxes2[..., 1]

    area1 = w1 * h1
    area2 = w2 * h2

    inter_max_xy = torch.min(bboxes1[..., 2:], bboxes2[..., 2:])
    inter_min_xy = torch.max(bboxes1[..., :2], bboxes2[..., :2])

    inter = torch.clamp((inter_max_xy - inter_min_xy), min=0)
    inter_area = inter[:, :, 0] * inter[:, :, 1]

    union = area1 + area2 - inter_area
    cbious = inter_area / union
    cbious = torch.clamp(cbious, min=0, max=1.0)
    if exchange:
        cbious = cbious.T
    return cbious




def iou_distance(atracks, btracks, type="iou"):  #普通的IOU距离
    """
    Compute cost based on IoU
    :type atracks: list[STrack]
    :type btracks: list[STrack]

    :rtype cost_matrix np.ndarray
    """

    if (len(atracks)>0 and isinstance(atracks[0], np.ndarray)) or (len(btracks) > 0 and isinstance(btracks[0], np.ndarray)):
        atlbrs = atracks
        btlbrs = btracks
    else:
        atlbrs = [track.tlbr for track in atracks]
        btlbrs = [track.tlbr for track in btracks]
        track_score = np.array([track.score for track in atracks])
        track_score = np.expand_dims(track_score, axis=0).repeat(len(atracks), axis=0)
        det_score = np.array([det.score for det in btracks])
        det_score = np.expand_dims(det_score, axis=1).repeat(len(btracks), axis=1)
    if type == "iou":
        _ious = ious(atlbrs, btlbrs)  #0-1
        cost_matrix = 1 - _ious
        return cost_matrix
    elif type == "ciou":
        _ious = bbox_overlaps_ciou(atlbrs, btlbrs)  #0-3
        cost_matrix = (1 - _ious) / 3
        cost_matrix = cost_matrix.numpy()
        return cost_matrix
    elif type == 'giou':
        _ious = bbox_overlaps_giou(atlbrs, btlbrs)  #-1-1
        cost_matrix = (1 - _ious) / 2
        cost_matrix = cost_matrix.numpy()
        return cost_matrix
    elif type == "diou":
        _ious = bbox_overlaps_diou(atlbrs, btlbrs)   #0-2
        cost_matrix = (1 - _ious) / 2
        cost_matrix = cost_matrix.numpy()
        return cost_matrix
    elif type == 'eiou':
        _ious = bbox_overlaps_eiou(atlbrs, btlbrs)   #0-4
        cost_matrix = (1 - _ious) / 4
        cost_matrix = cost_matrix.numpy()
        return cost_matrix
    elif type == 'ceiou':
        _ious = bbox_overlaps_ceiou(atlbrs, btlbrs)   #0-4
        cost_matrix = 1 - _ious
        cost_matrix = cost_matrix.numpy()
        return cost_matrix
    elif type == 'biou':
        _ious = bbox_overlaps_biou(atlbrs, btlbrs)
        cost_matrix = 1 - _ious
        cost_matrix = cost_matrix.numpy()
        return cost_matrix
    elif type == 'cbiou':
        _ious = bbox_overlaps_cbiou(atlbrs, btlbrs, track_score, det_score)
        cost_matrix = 1 - _ious
        cost_matrix = cost_matrix.numpy()
        return cost_matrix


def v_iou_distance(atracks, btracks):   #viou距离计算
    """
    Compute cost based on IoU
    :type atracks: list[STrack]
    :type btracks: list[STrack]

    :rtype cost_matrix np.ndarray
    """

    if (len(atracks)>0 and isinstance(atracks[0], np.ndarray)) or (len(btracks) > 0 and isinstance(btracks[0], np.ndarray)):
        atlbrs = atracks
        btlbrs = btracks
    else:
        atlbrs = [track.tlwh_to_tlbr(track.pred_bbox) for track in atracks]
        btlbrs = [track.tlwh_to_tlbr(track.pred_bbox) for track in btracks]
    _ious = ious(atlbrs, btlbrs)
    cost_matrix = 1 - _ious

    return cost_matrix


def embedding_distance(tracks, detections, metric='cosine'):   #外观距离计算，配EMA的
    """
    :param tracks: list[STrack]
    :param detections: list[BaseTrack]
    :param metric:
    :return: cost_matrix np.ndarray
    """

    cost_matrix = np.zeros((len(tracks), len(detections)), dtype=np.float)  #先建立一个空矩阵
    if cost_matrix.size == 0:
        return cost_matrix
    det_features = np.asarray([track.curr_feat for track in detections], dtype=np.float)   #检测的外观特征
    track_features = np.asarray([track.smooth_feat for track in tracks], dtype=np.float)    #轨迹的外观特征

    cost_matrix = np.maximum(0.0, cdist(track_features, det_features, metric))  # / 2.0  # Nomalized features
    return cost_matrix


def gate_cost_matrix(kf, cost_matrix, tracks, detections, only_position=False):   #自带汉明距离阈值的
    if cost_matrix.size == 0:
        return cost_matrix
    gating_dim = 2 if only_position else 4
    gating_threshold = kalman_filter.chi2inv95[gating_dim]
    # measurements = np.asarray([det.to_xyah() for det in detections])
    measurements = np.asarray([det.to_xywh() for det in detections])
    for row, track in enumerate(tracks):
        gating_distance = kf.gating_distance(
            track.mean, track.covariance, measurements, only_position)
        cost_matrix[row, gating_distance > gating_threshold] = np.inf
    return cost_matrix


def fuse_motion(kf, cost_matrix, tracks, detections, only_position=False, lambda_=0.98):    #马氏距离
    if cost_matrix.size == 0:
        return cost_matrix
    gating_dim = 2 if only_position else 4
    gating_threshold = kalman_filter.chi2inv95[gating_dim]
    # measurements = np.asarray([det.to_xyah() for det in detections])
    measurements = np.asarray([det.to_xywh() for det in detections])
    for row, track in enumerate(tracks):
        gating_distance = kf.gating_distance(
            track.mean, track.covariance, measurements, only_position, metric='maha')
        cost_matrix[row, gating_distance > gating_threshold] = np.inf
        cost_matrix[row] = lambda_ * cost_matrix[row] + (1 - lambda_) * gating_distance
    return cost_matrix


def fuse_iou(cost_matrix, tracks, detections):   #没用的函数
    if cost_matrix.size == 0:
        return cost_matrix
    reid_sim = 1 - cost_matrix
    iou_dist = iou_distance(tracks, detections)
    iou_sim = 1 - iou_dist
    fuse_sim = reid_sim * (1 + iou_sim) / 2
    det_scores = np.array([det.score for det in detections])
    det_scores = np.expand_dims(det_scores, axis=0).repeat(cost_matrix.shape[0], axis=0)
    #fuse_sim = fuse_sim * (1 + det_scores) / 2
    fuse_cost = 1 - fuse_sim
    return fuse_cost


def fuse_score(cost_matrix, detections):  #乘上分数的IOU距离
    if cost_matrix.size == 0:
        return cost_matrix
    iou_sim = 1 - cost_matrix   #IOU相似度
    det_scores = np.array([det.score for det in detections])
    det_scores = np.expand_dims(det_scores, axis=0).repeat(cost_matrix.shape[0], axis=0)
    fuse_sim = iou_sim * det_scores
    fuse_cost = 1 - fuse_sim
    return fuse_cost

def mask(cost_matrix,detections, tracks):
    det_scores = np.array([det.score for det in detections])
    det_scores = np.expand_dims(det_scores, axis=0).repeat(cost_matrix.shape[0], axis=0)
    track_score = np.array([(track.aff + track.smooth_score) / 2 for track in tracks])
    track_score = np.expand_dims(track_score, axis=1).repeat(cost_matrix.shape[1], axis=1)
    # track_score = np.array([track.smooth_score for track in tracks])
    # track_score = np.expand_dims(track_score, axis=1).repeat(cost_matrix.shape[1], axis=1)
    mask = track_score * det_scores
    return mask


def mask_iou(cost_matrix, detections, tracks):   #计算maskiou

    det_scores = np.array([det.score for det in detections])
    det_scores = np.expand_dims(det_scores, axis=0).repeat(cost_matrix.shape[0], axis=0)
    track_score = np.array([(track.aff + track.smooth_score) / 2 for track in tracks])
    track_score = np.expand_dims(track_score, axis=1).repeat(cost_matrix.shape[1], axis=1)
    # track_score = np.array([track.smooth_score for track in tracks])
    # track_score = np.expand_dims(track_score, axis=1).repeat(cost_matrix.shape[1], axis=1)
    mask = track_score * det_scores
    iou_sim = 1 - cost_matrix
    # mask_sim = track_score * iou_sim * det_scores
    mask_sim = np.multiply(iou_sim, mask)
    mask_cost = 1-mask_sim
    if cost_matrix.size == 0:
        return cost_matrix, mask, iou_sim, mask_sim
    return mask_cost, mask, iou_sim, mask_sim

#最后的输出行是轨迹，列是检测

def mask_embedding(cost_matrix, detections, tracks):   #计算maskapp
    if cost_matrix.size == 0:
        return cost_matrix
    app_sim = 1 - cost_matrix
    det_scores = np.array([det.score for det in detections])
    det_scores = np.expand_dims(det_scores, axis=0).repeat(cost_matrix.shape[0], axis=0)
    track_score = np.array([(track.aff + track.smooth_score) / 2 for track in tracks])
    track_score = np.expand_dims(track_score, axis=1).repeat(cost_matrix.shape[1], axis=1)
    mask_sim = track_score * app_sim * det_scores
    mask_cost = 1-mask_sim
    return mask_cost

# def mask_embedding(cost_matrix, detections, tracks):   #计算maskapp
#     if cost_matrix.size == 0:
#         return cost_matrix
#     app_sim = 1 - cost_matrix
#     det_scores = np.array([det.score for det in detections])
#     det_scores = np.expand_dims(det_scores, axis=0).repeat(cost_matrix.shape[0], axis=0)
#     app_sim_sort = np.sort(app_sim, axis=1)
#     max_val = app_sim_sort[:, -1]
#     second_max_val = app_sim_sort[:, -2]
#     # 将max_val和second_max_val分别沿第一个维度复制n_tracks次
#     max_val = np.tile(max_val, (cost_matrix.shape[1], 1)).T
#     second_max_val = np.tile(second_max_val, (cost_matrix.shape[1], 1)).T
#     track_score = max_val - second_max_val
#     mask_sim = track_score * app_sim * det_scores
#     mask_cost = 1 - mask_sim
#     return mask_cost


# def mask_embedding(cost_matrix, detections, tracks):  # 计算maskapp
#     if cost_matrix.size == 0:
#         return cost_matrix
#     app_sim = 1 - cost_matrix
#     app_sim_sort1 = np.sort(app_sim, axis=0)
#     max_det = app_sim_sort1[-1, :]
#     mean_det = np.mean(app_sim_sort1[:-1, :], axis=0)
#     max_det = np.tile(max_det, (cost_matrix.shape[0], 1))
#     mean_det = np.tile(mean_det, (cost_matrix.shape[0], 1))
#     det_scores = max_det - mean_det
#     app_sim_sort = np.sort(app_sim, axis=1)
#     max_val = app_sim_sort[:, -1]
#     second_max_val = np.mean(app_sim_sort[:, :-1], axis=1)
#     max_val = np.tile(max_val, (cost_matrix.shape[1], 1)).T
#     second_max_val = np.tile(second_max_val, (cost_matrix.shape[1], 1)).T
#     track_score = max_val - second_max_val
#     mask_sim = track_score * app_sim * det_scores
#     mask_cost = 1 - mask_sim
#     return mask_cost



import numpy as np
import pandas as pd
import xlrd
import xlwt


def save_array2execl(arraya, arrayb, arrayc,arrayd,arraye,arrayf, d):
    filename = xlwt.Workbook()  # 创建工作簿
    sheet1 = filename.add_sheet(u'mask_sim', cell_overwrite_ok=True)
    sheet2 = filename.add_sheet(u'mask_iou', cell_overwrite_ok=True)  # 创建sheet
    sheet3 = filename.add_sheet(u'mask_app', cell_overwrite_ok=True)
    sheet4 = filename.add_sheet(u'mask', cell_overwrite_ok=True)
    sheet5 = filename.add_sheet(u'IOU_sim', cell_overwrite_ok=True)
    sheet6 = filename.add_sheet(u'app_sim', cell_overwrite_ok=True)
    [h, l] = arraya.shape  # h为行数，l为列数
    for i in range(h):
        for j in range(l):
            sheet1.write(i, j, float(arraya[i, j]))
            sheet2.write(i, j, float(arrayb[i, j]))
            sheet3.write(i, j, float(arrayc[i, j]))
            sheet4.write(i, j, float(arrayd[i, j]))
            sheet5.write(i, j, float(arraye[i, j]))
            sheet6.write(i, j, float(arrayf[i, j]))
    filename.save(d)

def save_arrayexecl(arraya, arrayb, arrayc, d):
    filename = xlwt.Workbook()  # 创建工作簿
    sheet1 = filename.add_sheet(u'mask_sim', cell_overwrite_ok=True)
    sheet2 = filename.add_sheet(u'mask', cell_overwrite_ok=True)
    sheet3 = filename.add_sheet(u'IOU_sim', cell_overwrite_ok=True)
    [h, l] = arraya.shape  # h为行数，l为列数
    for i in range(h):
        for j in range(l):
            sheet1.write(i, j, float(arraya[i, j]))
            sheet2.write(i, j, float(arrayb[i, j]))
            sheet3.write(i, j, float(arrayc[i, j]))
    filename.save(d)

def save_iou(array, d):
    filename = xlwt.Workbook()  # 创建工作簿
    sheet1 = filename.add_sheet(u'IOU_sim', cell_overwrite_ok=True)  # 创建sheet
    [h, l] = array.shape  # h为行数，l为列数
    for i in range(h):
        for j in range(l):
            sheet1.write(i, j, float(array[i, j]))
    filename.save(d)


